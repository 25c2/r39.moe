---
home: true
title: Home
footer: Copyright © 2025-present r
---
# 👋 Hi there
---
### 自己紹介
変な人です
- 職業: どっかの学生
- 年齢: 15 (誕生日:2010/12/24)
- 趣味: 多趣味
- 居場所: チバラギ
